<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Blog</title>
</head>
<body>
    @yield('contenido')
</body>
</html>
