@extends('plantilla')

@section('contenido')
    @include('partials.nav')
    <h2>Crear Post</h2>
    <p>Formulario de creación de post.</p>
@endsection
