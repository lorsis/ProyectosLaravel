@extends('plantilla')

@section('titulo', 'Ficha post')

@section('contenido')
    <h1>Ficha del post {{ $post->id }}</h1>

    <p>{{ $post->contenido }}</p>

    <p><small>Creado: {{ $post->created_at }}</small></p>
@endsection
