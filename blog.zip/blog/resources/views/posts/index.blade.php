@extends('plantilla')

@section('titulo', 'Listado posts')

@section('contenido')
    <h1>Listado de posts</h1>

    <p>Vista de ejemplo (sesión 3). Aquí listaremos posts reales en sesiones posteriores.</p>

    <ul>
        @forelse ($posts as $post)
            <li>
                {{ $post->titulo }} ({{ optional($post->usuario)->login }})
                <a href="{{ route('posts_ficha', $post) }}">Ver</a>

                {{-- Borrado: formulario DELETE --}}
                <form action="{{ route('posts_destroy', $post) }}" method="POST" style="display:inline">
                    @method('DELETE')
                    @csrf
                    <button type="submit">Borrar</button>
                </form>
            </li>
        @empty
            <li>No hay posts</li>
        @endforelse
    </ul>

    {{-- Paginación si $posts es un LengthAwarePaginator --}}
    @if(method_exists($posts, 'links'))
        {{ $posts->links() }}
    @endif
@endsection
