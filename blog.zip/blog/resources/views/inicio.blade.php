@extends('plantilla')

@section('contenido')
    @include('partials.nav')
    <h1>Bienvenido {{ $nombre }}</h1>
    <p>Esta es la página principal de tu blog.</p>
@endsection
