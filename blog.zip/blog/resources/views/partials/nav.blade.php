<nav>
    <a href="{{ route('inicio') }}">Inicio</a>
    &nbsp;|&nbsp;
    <a href="{{ route('posts_listado') }}">Listado de posts</a>
    &nbsp;|&nbsp;
    <a href="{{ route('prueba_helper') }}">Prueba Helper</a>
</nav>
<hr>
