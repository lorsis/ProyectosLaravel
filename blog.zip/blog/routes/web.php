<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;

// Página principal
Route::get('/', function () {
    $nombre = "Invitado";
    return view('inicio', compact('nombre'));
})->name('inicio');

// Rutas CRUD de posts (index, show, create, edit, destroy)
Route::resource('posts', PostController::class)
    ->only(['index', 'show', 'create', 'edit', 'destroy'])
    ->names([
        'index' => 'posts_listado',   // posts.index en el controlador
        'show' => 'posts_ficha',      // posts.show en el controlador
        'create' => 'posts_create',
        'edit' => 'posts_edit',
        'destroy' => 'posts_destroy'
    ]);

// Ruta de prueba del helper
Route::get('/prueba-helper', [PostController::class, 'pruebaHelper'])->name('prueba_helper');
