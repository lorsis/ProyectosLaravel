

<?php $__env->startSection('titulo', 'Ficha post'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Ficha del post <?php echo e($post->id); ?></h1>

    <p><?php echo e($post->contenido); ?></p>

    <p><small>Creado: <?php echo e($post->created_at); ?></small></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>