

<?php $__env->startSection('titulo', 'Listado posts'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Listado de posts</h1>

    <p>Vista de ejemplo (sesión 3). Aquí listaremos posts reales en sesiones posteriores.</p>

    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li>
                <?php echo e($post->titulo); ?> (<?php echo e(optional($post->usuario)->login); ?>)
                <a href="<?php echo e(route('posts_ficha', $post)); ?>">Ver</a>

                
                <form action="<?php echo e(route('posts_destroy', $post)); ?>" method="POST" style="display:inline">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit">Borrar</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>No hay posts</li>
        <?php endif; ?>
    </ul>

    
    <?php if(method_exists($posts, 'links')): ?>
        <?php echo e($posts->links()); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/posts/index.blade.php ENDPATH**/ ?>