<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Blog</title>
</head>
<body>
    <?php echo $__env->yieldContent('contenido'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/plantilla.blade.php ENDPATH**/ ?>