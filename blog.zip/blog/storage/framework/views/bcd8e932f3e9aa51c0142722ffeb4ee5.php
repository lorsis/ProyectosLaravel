

<?php $__env->startSection('contenido'); ?>
    <?php echo $__env->make('partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <h1>Bienvenido <?php echo e($nombre); ?></h1>
    <p>Esta es la página principal de tu blog.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/inicio.blade.php ENDPATH**/ ?>