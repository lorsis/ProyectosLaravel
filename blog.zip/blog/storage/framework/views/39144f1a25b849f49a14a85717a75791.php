<nav>
    <a href="<?php echo e(route('inicio')); ?>">Inicio</a>
    &nbsp;|&nbsp;
    <a href="<?php echo e(route('posts_listado')); ?>">Listado de posts</a>
    &nbsp;|&nbsp;
    <a href="<?php echo e(route('prueba_helper')); ?>">Prueba Helper</a>
</nav>
<hr>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/nav.blade.php ENDPATH**/ ?>